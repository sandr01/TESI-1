import tkinter as tk
from janela_principal import Janela_Principal

root = tk.Tk()
Janela_Principal(root)
